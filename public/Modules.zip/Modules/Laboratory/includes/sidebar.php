<div class="be-left-sidebar">
        <div class="left-sidebar-wrapper"><a class="left-sidebar-toggle" href="ohcms_pages__dashboard.php">Dashboard</a>
          <div class="left-sidebar-spacer">
            <div class="left-sidebar-scroll">
              <div class="left-sidebar-content">
                <ul class="sidebar-elements">
                  <li class="divider">Menu</li>
                  <li class="active"><a href="ohcms_pages_employee_dashboard.php"><i class="icon mdi mdi-home"></i><span>Dashboard</span></a>
                  </li>
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-wheelchair-accessibility"></i><span>OutPatient</span></a>
                    <ul class="sub-menu">
                      </li>
                      </li>
                      <li><a href="ohcms_pages_employee_search_outpatient_records.php"><span class="badge badge-success float-right">New</span>Advanced Search</a>
                      </li>
                    </ul>
                  </li>
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-hotel"></i><span>InPatient</span></a>
                    <ul class="sub-menu">
                     
                      <li><a href="ohcms_pages_employee_advance_search_inpatients.php"><span class="badge badge-success float-right">New</span>Advanced Search</a>
                      </li>
                    </ul>
                  </li>
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-flask"></i><span>Laboratory </span></a>
                    <ul class="sub-menu">
                      <li><a href="ohcms_pages_employee_add_patient_lab_diag.php">Patient Diagonisis</a>
                      </li>
                      </li>
                    </ul>
                  </li>
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-folder-edit"></i><span>Capture Vitals</span></a>
                    <ul class="sub-menu">
                      <li><a href="ohcms_employee_pages_add_outpatient_vitals.php">OutPatient Vitals</a>
                      </li>
                      <li><a href="ohcms_employee_pages_add_inpatients_vitals.php">InPatient Vitals</a>
                      <li><a href="ohcms_employee_pages_add_employee_vitals.php">Employee Vitals</a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>