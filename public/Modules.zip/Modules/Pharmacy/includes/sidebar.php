<div class="be-left-sidebar">
        <div class="left-sidebar-wrapper"><a class="left-sidebar-toggle" href="ohcms_pages__dashboard.php">Dashboard</a>
          <div class="left-sidebar-spacer">
            <div class="left-sidebar-scroll">
              <div class="left-sidebar-content">
                <ul class="sidebar-elements">
                  <li class="divider">Menu</li>
                  <li class="active"><a href="ohcms_pages_employee_dashboard.php"><i class="icon mdi mdi-home"></i><span>Dashboard</span></a>
                  </li>
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-wheelchair-accessibility"></i><span>OutPatient</span></a>
                    <ul class="sub-menu">
                      <li><a href="ohcms_pages_employee_search_outpatient_records.php"><span class="badge badge-success float-right">New</span>Advanced Search</a>
                      </li>
                    </ul>
                  </li>
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-hotel"></i><span>InPatient</span></a>
                    <ul class="sub-menu">
                      
                      <li><a href="ohcms_pages_employee_advance_search_inpatients.php"><span class="badge badge-success float-right">New</span>Advanced Search</a>
                      </li>
                    </ul>
                  </li> 
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-flask"></i><span>Laboratory </span></a>
                    <ul class="sub-menu">
                      <li><a href="ohcms_pages_employee_add_patient_lab_diag.php">Patient Diagonisis</a>
                      </li>
                      </li>
                    </ul>
                  </li>
                  
                  <li class="parent active"><a href="#"><i class="icon mdi mdi-pharmacy"></i><span>Pharmacy</span></a>
                    <ul class="sub-menu">
                   
                      <li><a href="ohcms_pages_employee_add_pharmaceutical_category.php">Add Pharmaceutical Category</a></li>
                      <li><a href="ohcms_pages_employee_add_pharmaceutical.php">Add Pharmaceutical</a></li>
                      <li><a href="ohcms_pages_employee_advance_search_pharmaceutical.php">Advance Search </a>
                      <li><a href="ohcms_pages_employee_view_inpatients_prescriptions.php">Inpatient Drugs</a></li>
                      <li><a href="ohcms_pages_employee_view_outpatients_prescriptions.php">OutPatient Drugs</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>